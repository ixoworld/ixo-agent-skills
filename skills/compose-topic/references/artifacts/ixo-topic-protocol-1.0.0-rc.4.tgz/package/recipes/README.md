# Topic Recipe registry

These digest-addressed Topic Recipes are Marketplace-ready release-candidate
artifacts. Every recipe creates a user-reviewable Draft; none grants authority
or executes its Flow bindings.

- `research-brief.json`
- `agent-delivery.json`
- `verified-work-payment.json`

`registry.json` publishes the corresponding immutable references. Consumers
must verify the recipe digest before resolving the Effective Topic Shape.
