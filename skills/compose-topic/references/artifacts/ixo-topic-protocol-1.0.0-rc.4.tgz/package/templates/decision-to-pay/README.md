# Decision-to-Pay Topic template pack

This directory publishes versioned, machine-readable Topic Templates for
consequential payment decisions:

1. [Verified Work Payment v0.1](verified-work-payment.template.json) — the original generic contract extension, retained unchanged for compatibility.
2. [Verified Work Payment v0.2](verified-work-payment.v0.2.template.json) — the Claims-native candidate that binds a Deed, Job Topic, scoped AuthZ, intent escrow, claim, signed evaluation receipt, payment and canonical dispute.
3. [Payment on Delivery](payment-on-delivery.template.json)
4. [Milestone Payment Release](milestone-payment-release.template.json)
5. [Outcome Payment Claim](outcome-payment-claim.template.json)

The v1 manifests extend the Topic kinds, recipes, and external-work contracts
in `@ixo/topic-protocol` 0.7.0. Verified Work Payment v0.2 targets Topic
Protocol 0.8.0 and the canonical IXO Claims and Evaluation Engine interfaces.
Every compatibility block pins its reviewed baseline and required extensions.

## Shared contracts

- [`decision-to-pay-template.schema.json`](../../schemas/decision-to-pay-template.schema.json)
  validates each template manifest.
- [`payment-terms.schema.json`](../../schemas/payment-terms.schema.json) defines
  immutable commercial and control terms for one payable unit.
- [`payable-obligation.schema.json`](../../schemas/payable-obligation.schema.json)
  defines a payment-case envelope with separate delivery, evaluation, approval,
  claim, and settlement projections.
- Matching synthetic reference vectors live in [`examples/`](../../examples).

## Trust boundary

These artifacts do not grant a capability, verify a signature, establish
eligibility, approve a claim, or move money. For v1, Topic Protocol operations
and referenced records are the projected authorities. For Verified Work
Payment v0.2, the Deed owns the work package and the IXO Claims module owns
intent, escrow, claim, evaluation, payment, deposits, disputes, and
adjudication. A conforming runtime must verify DIDs, delegated capabilities,
signatures, revocation, replay protection, funding, evidence and rubric digests
before offering a chain transaction.

Neither Payable Obligation version is an alternative settlement authority.

## Draft and privacy rules

- A Topic may begin as an honest Draft with only a title and Kind.
- Missing intent, owner, outcome, authority, evidence, amount, or deadline must
  remain visibly missing until supplied or accepted.
- A template names required capabilities but never grants them.
- Confidential evidence stays in an appropriately scoped encrypted room or a
  UCAN-protected VFS resource. Topic membership does not grant VFS byte access.
- The example fixtures set `notRealEvidence: true`; zero digests and example
  identifiers must never be treated as verified evidence.

## Compatibility notes

The Job Card profile and external-work contracts support the strongest path for
Verified Work Payment. Physical delivery still needs a delivery-order resource
or profile. The milestone template uses one child Topic per payable milestone,
so corrections do not become new milestones. Outcome Payment Claim assumes a
Delivery Packet for the underlying intervention; claims without external work
need a future generalised obligation handoff.

The v2 Verified Work Payment contract deliberately uses separate schemas:

- [`decision-to-pay-template-v2.schema.json`](../../schemas/decision-to-pay-template-v2.schema.json) fixes the authority model: Deed for the work package, Job Topic for the binder/thread, Claims for execution, Evaluation Engine for the signed determination, and Portal for orchestration.
- [`payment-terms-v2.schema.json`](../../schemas/payment-terms-v2.schema.json) maps immutable accepted terms to Claim Collection, AuthZ, evaluation and dispute configuration.
- [`payable-obligation-v2.schema.json`](../../schemas/payable-obligation-v2.schema.json) is a read-only projection of chain and receipt evidence; it cannot approve or settle.

The v1 schemas and all other templates remain available and retain their original semantics.
