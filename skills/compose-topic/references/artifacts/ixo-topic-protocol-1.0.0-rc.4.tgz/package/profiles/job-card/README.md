# Job Card Kind Profile

`profile.json` is the immutable profile document for the first-party Job Kind
extension. It is pinned from Topic contracts by exact version and SHA-256
digest. The Job-specific resource validates against
`schemas/job-card.schema.json`.

Generic Topic clients fall back to the standard `task` Kind and `project`
recipe. Profile-aware clients may edit and project the room-visible fields
declared by the profile, but must keep the complete Job Card in the encrypted
contract body or its authorised bound resource.
